//
//  segmentkapian.h
//  xiaonongfu
//
//  Created by xuexi on 7/23/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^ButtonOnClickBlock)(NSInteger tag, NSString * title);
@interface segmentkapian : UIView
@property (nonatomic, strong) NSArray *titles;                      //标题数组
@property (nonatomic, strong) UIColor *titlesCustomeColor;          //标题的常规颜色
@property (nonatomic, strong) UIColor *titlesHeightLightColor;      //标题高亮颜色
@property (nonatomic, strong) UIColor *backgroundHeightLightColor;  //高亮时的颜色
@property (nonatomic, strong) UIFont *titlesFont;                   //标题的字号
@property (nonatomic, assign) CGFloat duration;                     //运动时间
@property (nonatomic, strong) UIView * heightLightView;
@property (nonatomic, strong) UIView * heightTopView;
-(void) setButtonOnClickBlock: (ButtonOnClickBlock) block;
-(CGRect) countCurrentRectWithIndex: (NSInteger) index;
@end
