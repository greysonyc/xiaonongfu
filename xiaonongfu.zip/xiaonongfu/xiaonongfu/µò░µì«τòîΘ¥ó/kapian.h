//
//  kapian.h
//  xiaonongfu
//
//  Created by xuexi on 7/23/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewControllerbianji.h"
#import "segmentkapian.h"
@interface kapian : UIView
@property (strong, nonatomic) IBOutlet UIImageView *picture;//作物图片
@property (strong, nonatomic) IBOutlet UILabel *mianji;//面积
@property (strong, nonatomic) IBOutlet UILabel *chanliang;//产量
@property (strong, nonatomic) IBOutlet UILabel *shangshi;//上市时间
@property (strong, nonatomic) IBOutlet UILabel *xiashi;//下市时间
@property (strong, nonatomic) IBOutlet UILabel *riqi;//日期
@property (strong, nonatomic) IBOutlet UILabel *name;//名字
@property (strong, nonatomic) IBOutlet UIButton *click;//按钮点击
@property (strong, nonatomic) IBOutlet UIButton *zuobutton;//左方向
@property (strong, nonatomic) IBOutlet UIButton *youbutton;//右方向

@end
