//
//  shuju.h
//  xiaonongfu
//
//  Created by xuexi on 7/23/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "ViewControllerdc.h"
#import "kapian.h"
#import "ViewControllershuju.h"
@interface shuju : UIViewController<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView*scrollview;//scrollview
@property(nonatomic,strong)UIPageControl * pagecontrol;//页面控制

@end
