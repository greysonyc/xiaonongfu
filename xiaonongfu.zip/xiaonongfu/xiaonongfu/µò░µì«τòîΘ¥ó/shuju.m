//
//  shuju.m
//  xiaonongfu
//
//  Created by xuexi on 7/23/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "shuju.h"

@interface shuju ()

@end

@implementation shuju

- (void)viewDidLoad {
    //
    self.navigationController.navigationBarHidden=YES;
    [self.navigationController setToolbarHidden:NO animated:YES];
    
    [self.navigationController.toolbar setBarStyle:UIBarStyleDefault];
    
    self.navigationController.toolbar.frame=CGRectMake(0, [UIScreen mainScreen].bounds.size.height-44, [UIScreen mainScreen].bounds.size.width, 44);
    
    
    
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc]
                                  
                                  initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                  
                                  target:nil action:nil];
    
    UIBarButtonItem *customItem1 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"状态1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain
                                    
                                    target:self action:@selector(toolBarItem1)];
    
    UIBarButtonItem *customItem2 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"通知"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]style:UIBarButtonItemStylePlain
                                    target:self action:@selector(toolBarItem2)];
    UIBarButtonItem *customItem3 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"数据1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain
                                    
                                    target:self action:@selector(toolBarItem3)];
    
    NSArray *arr1 = [[NSArray alloc]initWithObjects:customItem1,spaceItem,customItem2,spaceItem,customItem3, nil];
    
    self.toolbarItems = arr1;
    
    
    
    [super viewDidLoad];
    //scorllview，pagecontrol初始化
    self.scrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(10, 80, self.view.frame.size.width-20, self.view.frame.size.height-100)];
    [self.view addSubview:self.scrollview];
    self.automaticallyAdjustsScrollViewInsets=NO;
    self.pagecontrol=[[UIPageControl alloc]initWithFrame:CGRectMake(10, self.view.frame.size.height-50, self.view.frame.size.width-20, 20)];
    [self.view addSubview:self.pagecontrol];
    self.scrollview.bounces=YES;
    self.scrollview.pagingEnabled=YES;
    self.scrollview.showsHorizontalScrollIndicator=NO;
    self.scrollview.showsVerticalScrollIndicator=NO;
    self.scrollview.delegate=self;
    
    //输入假数据
    NSArray*array = [NSArray arrayWithObjects:[UIColor redColor],[UIColor greenColor],[UIColor blueColor],[UIColor yellowColor],[UIColor purpleColor],[UIColor orangeColor],nil];
    for (int i=0; i<[array count]; i++) {
        kapian * view=[[[NSBundle mainBundle] loadNibNamed:@"kapian"owner:self options:nil]firstObject];
        [view setFrame:CGRectMake((self.scrollview.frame.size.width-(self.scrollview.frame.size.width*4/4.8))/2+i*self.scrollview.frame.size.width, 60, self.scrollview.frame.size.width*4/4.8, self.scrollview.frame.size.height*3/4.2)];
        [view.zuobutton addTarget:self action:@selector(zuoclick:) forControlEvents:UIControlEventTouchUpInside];
        [view.youbutton addTarget:self action:@selector(youclick:) forControlEvents:UIControlEventTouchUpInside];
        [view.click addTarget:self action:@selector(buttonclick:) forControlEvents:UIControlEventTouchUpInside];
        [self.scrollview addSubview:view];
    }
    self.scrollview.contentSize=CGSizeMake([array count]*(self.view.frame.size.width-20), self.scrollview.frame.size.height);
    self.pagecontrol.numberOfPages=[array count];
    self.pagecontrol.currentPage=0;
    self.pagecontrol.hidden=YES;
    
    
    //初始化自定义segement
    segmentkapian *sg=[[segmentkapian alloc]init];
    sg.titles = @[@"第一次", @"第二次", @"第三次", @"第四次"];
    sg.duration = 0.2f;
    [sg setTag:1];
    [sg setButtonOnClickBlock:^(NSInteger tag, NSString *title) {
                NSLog(@"index = %ld, title = %@", (long)tag, title);
//        self.pagecontrol.currentPage=tag;
//        CGPoint c=self.scrollview.contentOffset;
//        [self.scrollview setContentOffset:CGPointMake(tag*self.scrollview.frame.size.width, c.y) animated:YES];
    }];
    [self.view addSubview:sg];
    [self addLayout:sg];
    // Do any additional setup after loading the view.
}

//
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if ([scrollView isMemberOfClass:[UITableView class]]) {
    }
    else{
        int index=fabs(scrollView.contentOffset.x)/scrollView.frame.size.width;
//        segmentkapian * view=[self.view viewWithTag:1];
//        CGRect frame = [view countCurrentRectWithIndex:index];
//        CGRect changeFrame = [view countCurrentRectWithIndex:-index];
//        view.duration=0.2f;
//        [UIView animateWithDuration:view.duration animations:^{
//            view.heightLightView.frame = frame;
//            view.heightTopView.frame = changeFrame;
//        } completion:^(BOOL finished) {
//        }];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//
-(void)toolBarItem1{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)toolBarItem2{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"tongzhi"];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)toolBarItem3{
    
}

- (void)addLayout: (UIView *)v {
    v.translatesAutoresizingMaskIntoConstraints = NO;
    NSLayoutConstraint *topConstraint = [NSLayoutConstraint
                                         constraintWithItem:v
                                         attribute:NSLayoutAttributeTop
                                         relatedBy:NSLayoutRelationEqual
                                         toItem:self.view
                                         attribute:NSLayoutAttributeTop
                                         multiplier:1
                                         constant:612];
    NSLayoutConstraint *leftConstraint = [NSLayoutConstraint
                                          constraintWithItem:v
                                          attribute:NSLayoutAttributeLeft
                                          relatedBy:NSLayoutRelationEqual
                                          toItem:self.view
                                          attribute:NSLayoutAttributeLeft
                                          multiplier:1
                                          constant:20];
    NSLayoutConstraint *rigthConstraint = [NSLayoutConstraint
                                           constraintWithItem:v
                                           attribute:NSLayoutAttributeRight
                                           relatedBy:NSLayoutRelationEqual
                                           toItem:self.view
                                           attribute:NSLayoutAttributeRight
                                           multiplier:1
                                           constant:-20];
    NSLayoutConstraint *heightConstraint = [NSLayoutConstraint
                                            constraintWithItem:v
                                            attribute:NSLayoutAttributeHeight
                                            relatedBy:NSLayoutRelationEqual
                                            toItem:nil
                                            attribute:NSLayoutAttributeHeight
                                            multiplier:1
                                            constant:70];
    [v addConstraint:heightConstraint];
    [self.view addConstraints:@[topConstraint, leftConstraint,rigthConstraint]];
    
    
    
}
-(void)zuoclick:(UIButton*)sender{
}
-(void)youclick:(UIButton*)sender{
    
}
-(void)buttonclick:(UIButton*)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewControllershuju *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"shuju"];
    [self.navigationController pushViewController:vc animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
