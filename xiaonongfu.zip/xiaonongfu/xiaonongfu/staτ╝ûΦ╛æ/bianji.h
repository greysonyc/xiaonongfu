//
//  bianji.h
//  xiaonongfu
//
//  Created by xuexi on 7/24/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bianji : UIView
@property (strong, nonatomic) IBOutlet UIButton *add;


@end
