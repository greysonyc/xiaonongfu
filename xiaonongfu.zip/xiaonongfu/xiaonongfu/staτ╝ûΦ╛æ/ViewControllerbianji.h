//
//  ViewControllerbianji.h
//  xiaonongfu
//
//  Created by xuexi on 7/23/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "segmentbianji.h"
#import "bianji.h"
#import "TableViewCellbianji.h"
#import "danli.h"
#import "mianjiviewcontroller.h"
@interface ViewControllerbianji : UIViewController<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UIButton *fanhui;//返回按钮
@property(nonatomic,strong)UIScrollView*scrollview;//scorlview
@property(nonatomic,strong)UIPageControl * pagecontrol;//页面控制器
@property(nonatomic,strong)UITableView * tableview;//tableview
@end
