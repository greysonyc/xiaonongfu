//
//  TableViewCellbianji.h
//  xiaonongfu
//
//  Created by xuexi on 7/24/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
//自定义cell
@interface TableViewCellbianji : UITableViewCell
@property (nonatomic, strong) UIImageView *headImageView;//头图片
@property (nonatomic, strong) UILabel *nameLabel;//作物数据名称
@property(nonatomic,strong)UILabel * resultlabel;//作物数据结果
+(instancetype)cellWithTableView:(UITableView*)tableview;//初始化方法
@end
