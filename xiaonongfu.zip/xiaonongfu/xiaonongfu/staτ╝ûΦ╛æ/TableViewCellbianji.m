//
//  TableViewCellbianji.m
//  xiaonongfu
//
//  Created by xuexi on 7/24/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "TableViewCellbianji.h"
@implementation TableViewCellbianji
//初始化方法实现
+ (instancetype)cellWithTableView:(UITableView *)tableView {
    static NSString *ID = @"cellID";
    TableViewCellbianji *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[TableViewCellbianji alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    return cell;
}
//初始化style
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initWithView];
    }
    return self;
}
//加子view
-(void)initWithView{
    _headImageView=[[UIImageView alloc]initWithImage:[UIImage imageNamed:@"Oval 2"]];
    [self.contentView addSubview:_headImageView];
    _nameLabel=[[UILabel alloc]init];
    _nameLabel.textColor=[UIColor blackColor];
    _nameLabel.font=[UIFont systemFontOfSize:16];
    _nameLabel.text=@"sdas";
    [self.contentView addSubview:_nameLabel];
    _resultlabel=[[UILabel alloc]init];
    _resultlabel.textColor=[UIColor blackColor];
    _resultlabel.font=[UIFont systemFontOfSize:24];
    _resultlabel.text=@"4000";
    [self.contentView addSubview:_resultlabel];
}
//设置viewframe
-(void)layoutSubviews{
    [super layoutSubviews];
    [_headImageView setFrame:CGRectMake(5, 40, 10, 10)];
    [_nameLabel setFrame:CGRectMake(35, 27, 100, 35)];
    [_resultlabel setFrame:CGRectMake(150, 27, 70, 35)];
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
