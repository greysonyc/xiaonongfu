//
//  ViewControllerbianji.m
//  xiaonongfu
//
//  Created by xuexi on 7/23/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "ViewControllerbianji.h"

@interface ViewControllerbianji ()
@property(strong,nonatomic)UILabel*mianjii;
@property(strong,nonatomic)UILabel*chanliang;
@end

@implementation ViewControllerbianji
//懒加载mianjii存储面积数值
-(UILabel*)mianjii{
    if(!_mianjii){
        _mianjii=[[UILabel alloc]init];
    }
    return _mianjii;
}
//懒加载chanliang存储产量
-(UILabel*)chanliang{
    if(!_chanliang){
        _chanliang=[[UILabel alloc]init];
    }
    return _chanliang;
}
//初始化此刻播种的次序
long indexbozhong=0;
//用于记录点击cell的位置
int tagg=999;


- (void)viewDidLoad {
    [super viewDidLoad];
//初始化自定义segment
    segmentbianji *sg=[[segmentbianji alloc]init];
    sg.tag=10;
    sg.titles=[[NSMutableArray alloc]initWithCapacity:100];
    [sg.titles addObject:@"第一次"];
    [sg.titles addObject:@"第二次"];
    [sg.titles addObject:@"第三次"];
    sg.duration=0.6f;
    [sg setTag:1];
    [sg setButtonOnClickBlock:^(NSInteger tag, NSString *title) {
        NSLog(@"index = %ld, title = %@", (long)tag, title);
        indexbozhong=tag;
        self.pagecontrol.currentPage=tag;
        CGPoint c=self.scrollview.contentOffset;
        [self.scrollview setContentOffset:CGPointMake(tag*self.scrollview.frame.size.width, c.y) animated:NO];
    }];
    [self.view addSubview:sg];
    [self addLayout:sg];
    
//初始化scorllview和pagecontrol
    self.scrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(40, 130, self.view.frame.size.width-80, self.view.frame.size.height-180)];
    [self.view addSubview:self.scrollview];
    self.automaticallyAdjustsScrollViewInsets=NO;
    self.pagecontrol=[[UIPageControl alloc]initWithFrame:CGRectMake(10, self.view.frame.size.height-50, self.view.frame.size.width-20, 20)];
    [self.view addSubview:self.pagecontrol];
    self.scrollview.bounces=YES;
    self.scrollview.pagingEnabled=YES;
    self.scrollview.showsHorizontalScrollIndicator=NO;
    self.scrollview.showsVerticalScrollIndicator=NO;
    self.scrollview.delegate=self;
    self.scrollview.scrollEnabled=NO;
    
// 输入假数据
    NSArray*array = [NSArray arrayWithObjects:[UIColor redColor],[UIColor greenColor],[UIColor blueColor],[UIColor yellowColor],nil];
    for (int i=0; i<[array count]; i++) {
        bianji * view=[[[NSBundle mainBundle] loadNibNamed:@"bianji"owner:self options:nil]firstObject];
        [view setFrame:CGRectMake((self.scrollview.frame.size.width-(self.scrollview.frame.size.width))/2+i*self.scrollview.frame.size.width, 30, self.scrollview.frame.size.width, self.scrollview.frame.size.height*3/3.2)];
        [view.add addTarget:self action:@selector(tianjiaclick:) forControlEvents:UIControlEventTouchUpInside];
        _tableview=[[UITableView alloc]initWithFrame:CGRectMake(20, 40, view.frame.size.width-40, view.frame.size.height-140)];
        _tableview.delegate=self;
        _tableview.dataSource=self;
        _tableview.separatorStyle=UITableViewCellSeparatorStyleNone;
        _tableview.scrollEnabled=NO;
        [_tableview setTag:999];
        [view setTag:i];
        [view addSubview:self.tableview];
        [self.scrollview addSubview:view];
    }
    self.scrollview.contentSize=CGSizeMake([array count]*(self.view.frame.size.width-20), self.scrollview.frame.size.height);
    self.pagecontrol.numberOfPages=[array count];
    self.pagecontrol.currentPage=0;
    self.pagecontrol.hidden=YES;
    // Do any additional setup after loading the view.
}

// 返回按钮点击事件
- (IBAction)fanhuiclick:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)viewWillDisappear:(BOOL)animated{
    [self.navigationController setToolbarHidden:YES animated:NO];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//viewwillappear实现传值
-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController setToolbarHidden:YES animated:NO];
    if (tagg==0) {
        _mianjii=[[UILabel alloc]init];
        _mianjii.text=[danli defaultdanli].str;
        bianji * view=[self.scrollview viewWithTag:indexbozhong];
        _tableview=[view viewWithTag:999];
        [_tableview reloadData];
    }
    else if (tagg==1){
        _chanliang=[[UILabel alloc]init];
        _chanliang.text=[danli defaultdanli].str;
        bianji * view=[self.scrollview viewWithTag:indexbozhong];
        _tableview=[view viewWithTag:999];
        [_tableview reloadData];
    }
    
   
}
//加segment约束
- (void)addLayout: (UIView *)v {
    v.translatesAutoresizingMaskIntoConstraints = NO;
    NSLayoutConstraint *topConstraint = [NSLayoutConstraint
                                         constraintWithItem:v
                                         attribute:NSLayoutAttributeTop
                                         relatedBy:NSLayoutRelationEqual
                                         toItem:self.view
                                         attribute:NSLayoutAttributeTop
                                         multiplier:1
                                         constant:70];
    NSLayoutConstraint *leftConstraint = [NSLayoutConstraint
                                          constraintWithItem:v
                                          attribute:NSLayoutAttributeLeft
                                          relatedBy:NSLayoutRelationEqual
                                          toItem:self.view
                                          attribute:NSLayoutAttributeLeft
                                          multiplier:1
                                          constant:20];
    NSLayoutConstraint *rigthConstraint = [NSLayoutConstraint
                                           constraintWithItem:v
                                           attribute:NSLayoutAttributeRight
                                           relatedBy:NSLayoutRelationEqual
                                           toItem:self.view
                                           attribute:NSLayoutAttributeRight
                                           multiplier:1
                                           constant:-20];
    NSLayoutConstraint *heightConstraint = [NSLayoutConstraint
                                            constraintWithItem:v
                                            attribute:NSLayoutAttributeHeight
                                            relatedBy:NSLayoutRelationEqual
                                            toItem:nil
                                            attribute:NSLayoutAttributeHeight
                                            multiplier:1
                                            constant:60];
    [v addConstraint:heightConstraint];
    [self.view addConstraints:@[topConstraint, leftConstraint,rigthConstraint]];
    
    
    
}

//tableview参数设置
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    TableViewCellbianji *cell = [TableViewCellbianji cellWithTableView:tableView];
  cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    if(indexPath.section==1){
        cell.resultlabel.text=_chanliang.text;
        cell.nameLabel.text=@"实际产量";
       UILabel*kg=[[UILabel alloc]initWithFrame:CGRectMake(220, 27, 35, 35)];
        kg.text=@"kg";
        kg.font=[UIFont systemFontOfSize:16];
        [cell addSubview:kg];
    }
    else if(indexPath.section==0){
        cell.resultlabel.text=_mianjii.text;
        cell.nameLabel.text=@"播种面积";
        NSLog(@"%@", _mianjii.text);
        NSLog(@"%@",cell.resultlabel.text);
        UILabel*mianji=[[UILabel alloc]initWithFrame:CGRectMake(220, 27, 50, 35)];
        mianji.text=@"km^2";
        mianji.font=[UIFont systemFontOfSize:16];
        [cell addSubview:mianji];
    }
    else if (indexPath.section==2){
        cell.nameLabel.text=@"上市时间";
    }
    else if (indexPath.section==3){
        cell.nameLabel.text=@"下市时间";
    }
 return cell;
   
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 85;
}



//tableview点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        mianjiviewcontroller *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"mianjibianji"];
        TableViewCellbianji*cell=[tableView cellForRowAtIndexPath:indexPath];
        [danli defaultdanli].str=cell.resultlabel.text;
        [self.navigationController pushViewController:vc animated:YES];
        tagg=0;
        NSLog(@"%@", cell.resultlabel.text);
//        NSLog(@"%@", indexPath);
    }
    else if (indexPath.section==1){
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        mianjiviewcontroller *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"mianjibianji"];
        TableViewCellbianji*cell=[tableView cellForRowAtIndexPath:indexPath];
        [danli defaultdanli].str=cell.resultlabel.text;
        [self.navigationController pushViewController:vc animated:YES];
        tagg=1;
        NSLog(@"%@", cell.resultlabel.text);
    }
}

//添加按钮
-(void)tianjiaclick:(UIButton*)sender{
    segmentbianji * sgg=(segmentbianji*)[self.view viewWithTag:10];
    [sgg.titles addObject:@"第五次"];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
