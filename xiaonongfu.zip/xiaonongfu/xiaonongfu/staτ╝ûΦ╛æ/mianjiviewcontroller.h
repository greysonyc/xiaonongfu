//
//  mianjiviewcontroller.h
//  xiaonongfu
//
//  Created by xuexi on 7/24/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "danli.h"
@interface mianjiviewcontroller : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *fanhui;//返回按钮
@property (strong, nonatomic) IBOutlet UIButton *baocun;//保存按钮
@property (strong, nonatomic) IBOutlet UITextField *text;//文本保存


@end
