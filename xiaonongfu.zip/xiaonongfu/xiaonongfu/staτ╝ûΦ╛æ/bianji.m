//
//  bianji.m
//  xiaonongfu
//
//  Created by xuexi on 7/24/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "bianji.h"

@implementation bianji

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
//-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
//    return 4;
//}
//-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
//    return 1;
//}
@end
