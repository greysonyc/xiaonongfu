//
//  danli.m
//  xiaonongfu
//
//  Created by xuexi on 7/24/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "danli.h"

@implementation danli
+(danli*)defaultdanli{
    static danli *dan=nil;
    if (dan==nil) {
        dan=[[danli alloc]init];
    }
    return dan;
}
@end
