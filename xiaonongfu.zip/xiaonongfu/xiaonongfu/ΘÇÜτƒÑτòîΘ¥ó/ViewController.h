//
//  ViewController.h
//  xiaonongfu
//
//  Created by xuexi on 7/15/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewControllerdc.h"
#import "shuju.h"
@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
@property (strong, nonatomic) IBOutlet UIButton *shangshi;//上市按钮
@property (strong, nonatomic) IBOutlet UIButton *xiashi;//下市按钮
@property (strong, nonatomic) IBOutlet UITableView *tableview;//显示数据的tableview
@property (strong, nonatomic) IBOutlet UIButton *bozhong;//播种按钮
@property (strong, nonatomic) IBOutlet UIButton *search;//查询按钮
@property(strong,nonatomic)NSMutableArray*bozhongclass;//存储播种类别作物
@property(strong,nonatomic)NSMutableArray * shangshiclass;//存储上市类别作物
@property(strong,nonatomic)NSMutableArray * xiashiclass;//存储下市类别作物
@property(strong,nonatomic)NSMutableArray * classfruit;//用于衔接
@end

