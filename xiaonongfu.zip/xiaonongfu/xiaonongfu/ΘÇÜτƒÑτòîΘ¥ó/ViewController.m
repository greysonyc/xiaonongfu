//
//  ViewController.m
//  xiaonongfu
//
//  Created by xuexi on 7/15/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
{
    UISearchBar * _searchbar;//定义searchbar
    NSArray*_searchdata;//存储search的结果
    BOOL _issearch;//判断是否处于search状态
    

}




- (void)viewDidLoad {
    //自定义toolbar
    self.navigationController.navigationBarHidden=YES;
    [self.navigationController setToolbarHidden:NO animated:YES];
    
    [self.navigationController.toolbar setBarStyle:UIBarStyleDefault];
    
    self.navigationController.toolbar.frame=CGRectMake(0, [UIScreen mainScreen].bounds.size.height-44, [UIScreen mainScreen].bounds.size.width, 44);
    
    
    
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc]
                                  
                                  initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                  
                                  target:nil action:nil];
    
    UIBarButtonItem *customItem1 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"状态1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain
                                    
                                    target:self action:@selector(toolBarItem1:)];

    UIBarButtonItem *customItem2 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"通知1"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]style:UIBarButtonItemStylePlain
                                    target:self action:@selector(toolBarItem2:)];

    UIBarButtonItem *customItem3 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"数据"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain
                                    
                                    target:self action:@selector(toolBarItem3:)];

    NSArray *arr1 = [[NSArray alloc]initWithObjects:customItem1,spaceItem,customItem2,spaceItem,customItem3, nil];
    
    self.toolbarItems = arr1;
    
    
    
    
    [super viewDidLoad];

    
    //输入数据
    self.shangshi.selected=!self.shangshi.selected;
    [self.shangshi setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
    _issearch=NO;
    self.bozhongclass=[[NSMutableArray alloc]initWithObjects:@"白菜",@"fq",@"asd",@"fdas",@"sadf",@"asd", nil];
    self.classfruit=self.bozhongclass;
    self.shangshiclass=[[NSMutableArray alloc]initWithObjects:@"白菜",@"fq123",@"asd123",@"fdas123",@"sadf123",@"asd123", nil];
    self.xiashiclass=[[NSMutableArray alloc]initWithObjects:@"白菜",@"fq344",@"asd344",@"fdas344",@"sadf344",@"asd344", nil];
    //设置tableview属性
    self.tableview.dataSource=self;
    self.tableview.delegate=self;
    self.tableview.bounces=NO;
 
    
  
}
//tableview的属性设置
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 85;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString*cellid=@"shangshi";
    NSInteger rowno=indexPath.row;
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:cellid forIndexPath:indexPath];
    if (!_issearch) {
        UILabel * label3 = (UILabel*)[cell viewWithTag:3];
        label3.text=self.classfruit[rowno];
        UILabel*label4=(UILabel*)[cell viewWithTag:4];
        if (_bozhong.isSelected) {
            label4.text=@"距离播种";
        }
        else if(_shangshi.isSelected){
            label4.text=@"距离上市";
        }
        else{
            label4.text=@"距离下市";
        }
    }
    else{
         UILabel * label3 = (UILabel*)[cell viewWithTag:3];

            label3.text=self.classfruit[rowno];
            label3.text=_searchdata[rowno];
        
        UILabel*label4=(UILabel*)[cell viewWithTag:4];
        if (_bozhong.isSelected) {
            label4.text=@"距离播种";
        }
        else if(_shangshi.isSelected){
            label4.text=@"距离上市";
        }
        else{
            label4.text=@"距离下市";
        }
    }
    return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(_issearch){
        return _searchdata.count;
    }
    else{
    return self.classfruit.count;
    }
}


//tableview添加删除
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}
-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"删除";
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
   
    if(editingStyle==UITableViewCellEditingStyleDelete){
        UIAlertController * alertcontroller = [UIAlertController alertControllerWithTitle:@"提示" message:@"你确定删除？" preferredStyle:UIAlertControllerStyleAlert];
        [alertcontroller addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {

            [_classfruit removeObjectAtIndex:indexPath.row];
            
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }]];
        [alertcontroller addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
    
        }]];
         [self presentViewController:alertcontroller animated:YES completion:nil];
    }
}



//searchbar点击执行搜索功能
-(void)searchBarCancelButtonClicked:(UISearchBar *)searchBar{
    _issearch=NO;
    _searchbar.text=NULL;
    self.tableview.tableHeaderView=NULL;
    [self.tableview reloadData];
}
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText{
    if (_searchbar.text.length==0) {
        _issearch=NO;
        [self.tableview reloadData];
    }
    else{
    [self filterBySubstring:searchBar.text];
    }
}
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [self filterBySubstring:searchBar.text];
    [searchBar resignFirstResponder];
}
-(BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    _searchbar.showsCancelButton=YES;
    for (UIView *view in [[_searchbar.subviews lastObject] subviews]) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *cancelBtn = (UIButton*)view;
            [cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
            [cancelBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
    }
    return YES;
}
-(void)filterBySubstring:(NSString*)subStr{
    _issearch=YES;
    NSPredicate * pred = [NSPredicate predicateWithFormat:@"SELF CONTAINS[c] %@",subStr];
    _searchdata=[self.classfruit filteredArrayUsingPredicate:pred];
    [self.tableview reloadData];
}






//下市按钮点击
- (IBAction)xiashiclick:(UIButton *)sender {
    sender.selected=!sender.selected;
    if (self.shangshi.selected) {
        self.shangshi.selected=!self.shangshi.selected;
    }
    if (self.bozhong.selected) {
        self.bozhong.selected=!self.bozhong.selected;
    }
    if (sender.isSelected) {
        [sender setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        self.classfruit=self.xiashiclass;
        NSIndexSet*indexset=[[NSIndexSet alloc]initWithIndex:0];
        [self.tableview reloadSections:indexset withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{
        [sender setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
    
}
//上市按钮点击
- (IBAction)shangshiclick:(UIButton *)sender {
    sender.selected=!sender.selected;
    if (self.bozhong.selected) {
        self.bozhong.selected=!self.bozhong.selected;
    }
    if (self.xiashi.selected) {
        self.xiashi.selected=!self.xiashi.selected;
    }
    if (sender.isSelected) {
        [sender setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        self.classfruit=self.shangshiclass;
        NSIndexSet*indexset=[[NSIndexSet alloc]initWithIndex:0];
        [self.tableview reloadSections:indexset withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{
       [sender setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
    
}
//播种按钮点击
- (IBAction)bozhongclick:(UIButton *)sender {
    sender.selected=!sender.selected;
    if (self.shangshi.selected) {
        self.shangshi.selected=!self.shangshi.selected;
    }
    if (self.xiashi.selected) {
        self.xiashi.selected=!self.xiashi.selected;
    }
    if (sender.isSelected) {
        [sender setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        self.classfruit=self.bozhongclass;
        NSIndexSet*indexset=[[NSIndexSet alloc]initWithIndex:0];
        [self.tableview reloadSections:indexset withRowAnimation:UITableViewRowAnimationAutomatic];
    }
    else{
        [sender setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    }
    
}


//searchbar按钮点击
- (IBAction)searchbar:(UIButton *)sender {
    if(sender.isSelected){
    self.tableview.tableHeaderView=NULL;
    }
    else{
        
        _searchbar=[[UISearchBar alloc]initWithFrame:CGRectMake(59, 17, 275, 56)];
        _searchbar.placeholder=@"输入要查询的作物";
        //    _searchbar.showsCancelButton=YES;
        self.tableview.tableHeaderView=_searchbar;
        _searchbar.delegate=self;
    }
    sender.selected=!sender.selected;
}




//toolbar点击事件
-(void)toolBarItem1:(UIBarButtonItem*)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void)toolBarItem2:(UIBarButtonItem*)sender{
}
-(void)toolBarItem3:(UIBarButtonItem*)sender{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    shuju *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"sj"];
    [self.navigationController pushViewController:vc animated:YES];
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
