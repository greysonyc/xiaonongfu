//
//  ViewControllerdc.h
//  xiaonongfu
//
//  Created by xuexi on 7/16/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "dc.h"
#import "dcbuttondelegate.h"
#import "chakanview.h"
#import "ViewController.h"
#import "shuju.h"
@interface ViewControllerdc : UIViewController<UIScrollViewDelegate,dcbuttondelegate>
@property (strong, nonatomic) IBOutlet UIImageView *datacard;//英文字datacard
@property (strong, nonatomic) IBOutlet UIImageView *background;//绿色背景
@property (strong, nonatomic) IBOutlet UIImageView *zuowu;//中文作物资料卡
@property (strong, nonatomic) IBOutlet UIButton *yonghu;// 按钮，点击可进入用户登陆界面
@property (strong, nonatomic) IBOutlet UIScrollView *scrollview;//提供各种作物的资料卡
@end
