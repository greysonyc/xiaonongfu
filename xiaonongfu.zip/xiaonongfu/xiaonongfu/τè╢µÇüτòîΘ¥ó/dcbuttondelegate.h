//
//  dcbuttondelegate.h
//  xiaonongfu
//
//  Created by xuexi on 7/16/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol dcbuttondelegate <NSObject>
-(void) myButtonDidTap: (UIButton*) sender;//协议 实现按钮的点击事件
@end
