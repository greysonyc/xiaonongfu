//
//  chakanview.h
//  xiaonongfu
//
//  Created by xuexi on 7/17/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface chakanview : UIView
@property (strong, nonatomic) IBOutlet UILabel *number;//xib自定义view
@end
