//
//  ViewControllerdc.m
//  xiaonongfu
//
//  Created by xuexi on 7/16/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "ViewControllerdc.h"

@interface ViewControllerdc ()

@end

@implementation ViewControllerdc
int count=0;
- (void)viewDidLoad {
//创建自定义toolbar
    self.navigationController.navigationBarHidden=YES;
    [self.navigationController setToolbarHidden:NO animated:YES];
    
    [self.navigationController.toolbar setBarStyle:UIBarStyleDefault];
    
    self.navigationController.toolbar.frame=CGRectMake(0, [UIScreen mainScreen].bounds.size.height-44, [UIScreen mainScreen].bounds.size.width, 44);
    
    
    
    UIBarButtonItem *spaceItem = [[UIBarButtonItem alloc]
                                  
                                  initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace
                                  
                                  target:nil action:nil];
    
    UIBarButtonItem *customItem1 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"状态"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain
                                    
                                    target:self action:@selector(toolBarItem1)];
    
    UIBarButtonItem *customItem2 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"通知"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]style:UIBarButtonItemStylePlain
                                    target:self action:@selector(toolBarItem2)];
    UIBarButtonItem *customItem3 = [[UIBarButtonItem alloc]
                                    
                                    initWithImage:[[UIImage imageNamed:@"数据"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] style:UIBarButtonItemStylePlain
                                    
                                    target:self action:@selector(toolBarItem3)];
    
    NSArray *arr1 = [[NSArray alloc]initWithObjects:customItem1,spaceItem,customItem2,spaceItem,customItem3, nil];
    
    self.toolbarItems = arr1;
    
    
    
    
    
    [super viewDidLoad];
    
    
//设置scrollview属性
    self.automaticallyAdjustsScrollViewInsets=YES;
    
    self.scrollview.delegate=self;
    
    self.scrollview.bounces=NO;
    self.scrollview.pagingEnabled=NO;
    self.scrollview.scrollEnabled=YES;
    self.scrollview.showsHorizontalScrollIndicator=NO;
    self.scrollview.showsVerticalScrollIndicator=YES;
    
    
    
    
//给scoreview里加内容
    NSArray*array = [NSArray arrayWithObjects:[UIColor redColor],[UIColor greenColor],[UIColor blueColor],[UIColor yellowColor],[UIColor purpleColor],[UIColor orangeColor],nil];
    for (int i=0; i<[array count]; i++) {
        dc * view=[[[NSBundle mainBundle] loadNibNamed:@"View"owner:self options:nil]firstObject];
        [view setFrame:CGRectMake(22, i*self.scrollview.frame.size.width, self.scrollview.frame.size.width-10, self.scrollview.frame.size.height-29)];
        view.delegate=self;//将控制器为代理实现button的方法
        [self.scrollview addSubview:view];
    }
    self.scrollview.contentSize = CGSizeMake(0,
                                             [array count]*(50+self.scrollview.frame.size.height));
}

//点击查看生长状况
-(void)myButtonDidTap:(UIButton *)sender{
    int q=0;
    CGRect r=self.scrollview.frame;
    if(sender.isSelected){//根据弹出的图框，改变scrollview的frame
        r.size.height -= 180;
        if (count==1) {
            r.origin.x=0;
            r.origin.y=219;
            [self.background setFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 289)];
            [self.background setImage:[UIImage imageNamed:@"矩形 1"]];
            [self.datacard setAlpha:1];
            [self.zuowu setAlpha:1];
            [self.yonghu setAlpha:1];
        }
        for(int i = 0;i<=self.scrollview.subviews.count-1;i++){
            if([self.scrollview.subviews objectAtIndex:i]==sender.superview){
                i=i+1;
                q=i;
            }
        }
        for (int m=q; m<=self.scrollview.subviews.count-1; m++) {
            if([[self.scrollview.subviews objectAtIndex:m]isKindOfClass:[dc class]]){
            CGRect r1=[self.scrollview.subviews objectAtIndex:m].frame;
            [[self.scrollview.subviews objectAtIndex:m]setFrame:CGRectMake(r1.origin.x,r1.origin.y-100,r1.size.width,r1.size.height)];
            }
        }
        
                for (long i = [self.scrollview.subviews indexOfObject:sender.superview]+1; i<self.scrollview.subviews.count-1; i++) {
                    CGRect r1=[self.scrollview.subviews objectAtIndex:i+1].frame;
                    [[self.scrollview viewWithTag:i]setFrame:CGRectMake(r1.origin.x,r1.origin.y-165,self.scrollview.frame.size.width-50, 50)];
                }
        
        if ([self.scrollview.subviews indexOfObject:sender.superview]==0) {
            [[self.scrollview viewWithTag:9999]removeFromSuperview];
        }else{
        [[self.scrollview viewWithTag:[self.scrollview.subviews indexOfObject:sender.superview]]removeFromSuperview];
        }
        count-=1;
    }
    else{
        chakanview * view=[[[NSBundle mainBundle] loadNibNamed:@"Viewchakan"owner:self options:nil]firstObject];
        [view setFrame:CGRectMake(22, sender.superview.frame.origin.y+350, self.scrollview.frame.size.width-50, 50)];
        long t=[self.scrollview.subviews indexOfObject:sender.superview];
        if(t==0)t=9999;
        [view setTag:t];
        view.userInteractionEnabled=NO;
        [self.scrollview addSubview:view];
        [self.datacard setAlpha:0];
        [self.zuowu setAlpha:0];
        [self.yonghu setAlpha:0];
        [self.background setFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width, 160)];
        [self.background setImage:[UIImage imageNamed:@"dianjiback"]];
        r.size.height += 180;
            r.origin.x=0;
            r.origin.y=67;
        for(int i = 0;i<=self.scrollview.subviews.count-1;i++){
            if([self.scrollview.subviews objectAtIndex:i]==sender.superview){
                i=i+1;
                q=i;
            }
            
        }
        
        for (int m=q; m<=self.scrollview.subviews.count-1; m++) {
            if([[self.scrollview.subviews objectAtIndex:m]isKindOfClass:[dc class]]){
            CGRect r1=[self.scrollview.subviews objectAtIndex:m].frame;
            [[self.scrollview.subviews objectAtIndex:m]setFrame:CGRectMake(r1.origin.x,r1.origin.y+100,r1.size.width,r1.size.height)];
            }
        }
        for (long i = [self.scrollview.subviews indexOfObject:sender.superview]+1; i<self.scrollview.subviews.count-1; i++) {
            CGRect r1=[self.scrollview.subviews objectAtIndex:i].frame;
            [[self.scrollview viewWithTag:i]setFrame:CGRectMake(r1.origin.x,r1.origin.y+350,self.scrollview.frame.size.width-50, 50)];
        }

        count+=1;
    }
    self.scrollview.frame=r;
}


//设置toolbar的点击事件
-(void)toolBarItem1{
    
}
-(void)toolBarItem2{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"tongzhi"];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)toolBarItem3{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    shuju *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"sj"];
    [self.navigationController pushViewController:vc animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
