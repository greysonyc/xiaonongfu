//
//  dc.h
//  xiaonongfu
//
//  Created by xuexi on 7/16/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "dcbuttondelegate.h"
@interface dc : UIView//自定义的datacardview
@property (strong, nonatomic) IBOutlet UILabel *name;//作物名字
@property (strong, nonatomic) IBOutlet UIImageView *im;//作物图片
@property (strong, nonatomic) IBOutlet UILabel *Englishname;//作物英文名
@property (strong, nonatomic) IBOutlet UIButton *ck;//作物点击button
@property(nonatomic,weak)id <dcbuttondelegate> delegate;
@end
