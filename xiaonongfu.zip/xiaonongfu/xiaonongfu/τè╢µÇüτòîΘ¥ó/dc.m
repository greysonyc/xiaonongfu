//
//  dc.m
//  xiaonongfu
//
//  Created by xuexi on 7/16/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "dc.h"

@implementation dc

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (IBAction)click:(UIButton *)sender {
    if(self.ck.isSelected){
        [_delegate myButtonDidTap:self.ck];
        [self.ck setImage:[UIImage imageNamed:@"查看生长状况button"] forState:UIControlStateNormal];
        self.ck.selected=!self.ck.selected;
        self.ck.frame=CGRectMake(0, 256, 375, 123);
        
    }
    else{
         [_delegate myButtonDidTap:self.ck];
    self.ck.selected=!self.ck.selected;
    [self.ck setImage:[UIImage imageNamed:@"收起"] forState:UIControlStateNormal];
    self.ck.frame=CGRectMake(21, 280, 325, 62);
       
    }
}
-(instancetype)initWithFrame:(CGRect)frame{
//    if (self=[super initWithFrame:frame]) {
//        self.background=[[UIImageView alloc]initWithFrame:self.frame];
//        [self.background setImage:[UIImage imageNamed:@"dc圆角矩形"]];
//        [self addSubview:self.background];
//        self.ck=[[UIButton alloc]init];
//        [self.ck setImage:[UIImage imageNamed:@"查看生长状况button"] forState:UIControlStateNormal];
//        [self addSubview:self.ck];
//        UIImage * im1=[UIImage imageNamed:@"图片"];
//        self.im = [[UIImageView alloc]initWithImage:im1];
//        [self addSubview:self.im];
//        self.name=[[UITextView alloc]init];
//        self.englishname = [[UITextView alloc]init];
//        [self addSubview:self.name];
//        [self addSubview:self.englishname];
//    }
    
   return self;
}
//-(void)layoutSubviews{
//    [super layoutSubviews];
//    CGSize size = self.frame.size;
//    self.ck.frame=CGRectMake(0, self.frame.size.height, self.frame.size.width, self.frame.size.height-400);
//    self.im.frame=CGRectMake(0, 0, size.width/5, size.height/5);
//    self.name.frame = CGRectMake(self.im.frame.size.width, self.im.frame.size.height/2, size.width/5, size.height/5);
//    self.englishname.frame=CGRectMake(self.im.frame.size.width, self.im.frame.size.height, size.width/5, size.height/5);
//}
@end
