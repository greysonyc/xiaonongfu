//
//  ViewControllershuju.h
//  xiaonongfu
//
//  Created by xuexi on 7/19/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "ViewControllerdc.h"
#import "shujuzhanshi.h"
#import "segment.h"
#import "ViewControllerbianji.h"
@interface ViewControllershuju : UIViewController
@property (strong, nonatomic) IBOutlet UIButton *fanhui;//返回按钮
@property (strong, nonatomic) IBOutlet UIButton *bianji;//编辑按钮
@end
