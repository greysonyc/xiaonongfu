//
//  shujuzhanshi.h
//  xiaonongfu
//
//  Created by xuexi on 7/21/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface shujuzhanshi : UIView
@property (strong, nonatomic) IBOutlet UILabel *riqi;//日期
@property (strong, nonatomic) IBOutlet UILabel *mianji;//面积
@property (strong, nonatomic) IBOutlet UILabel *chanliang;//产量
@property (strong, nonatomic) IBOutlet UILabel *shangshi;//上市
@property (strong, nonatomic) IBOutlet UILabel *xiashi;//下市

@end
