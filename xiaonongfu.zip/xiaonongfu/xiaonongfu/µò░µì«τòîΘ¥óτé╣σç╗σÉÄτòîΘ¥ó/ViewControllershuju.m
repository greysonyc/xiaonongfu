//
//  ViewControllershuju.m
//  xiaonongfu
//
//  Created by xuexi on 7/19/18.
//  Copyright © 2018 dcl. All rights reserved.
//

#import "ViewControllershuju.h"

@interface ViewControllershuju ()

@end

@implementation ViewControllershuju

- (void)viewDidLoad {
    
    self.navigationController.navigationBarHidden=YES;
    [self.navigationController setToolbarHidden:YES animated:YES];
  
    [super viewDidLoad];
    
    
    //初始化shujuzhanshi视图
    shujuzhanshi*view1=[[[NSBundle mainBundle] loadNibNamed:@"shujuzhanshi"owner:self options:nil]firstObject];
    [view1 setFrame:CGRectMake(0,150,self.view.frame.size.width , 280)];
    [self.view addSubview:view1];
    
    
    //设置初始化自定义segment
    segment *sg=[[segment alloc]init];
    sg.titles = @[@"第一次", @"第二次", @"第三次", @"第四次"];
    sg.duration = 0.7f;
    
    [sg setButtonOnClickBlock:^(NSInteger tag, NSString *title) {
//        NSLog(@"index = %ld, title = %@", (long)tag, title);
        [view1 removeFromSuperview];
        shujuzhanshi*view=[[[NSBundle mainBundle] loadNibNamed:@"shujuzhanshi"owner:self options:nil]firstObject];
        [view setFrame:CGRectMake(0,150,self.view.frame.size.width , 280)];
        view.mianji.text=@"23";
        [self.view addSubview:view];
    }];
    [self.view addSubview:sg];
    [self addLayout:sg];
    // Do any additional setup after loading the view.
}


//返回按钮点击事情
- (IBAction)fanhuiclick:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

//编辑按钮点击事情
- (IBAction)bianjiclick:(UIButton *)sender {
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"bianji"];
    [self.navigationController pushViewController:vc animated:YES];
}
//添加约束
- (void)addLayout: (UIView *)v {
    v.translatesAutoresizingMaskIntoConstraints = NO;
    NSLayoutConstraint *topConstraint = [NSLayoutConstraint
                                         constraintWithItem:v
                                         attribute:NSLayoutAttributeTop
                                         relatedBy:NSLayoutRelationEqual
                                         toItem:self.view
                                         attribute:NSLayoutAttributeTop
                                         multiplier:1
                                         constant:80];
    NSLayoutConstraint *leftConstraint = [NSLayoutConstraint
                                          constraintWithItem:v
                                          attribute:NSLayoutAttributeLeft
                                          relatedBy:NSLayoutRelationEqual
                                          toItem:self.view
                                          attribute:NSLayoutAttributeLeft
                                          multiplier:1
                                          constant:20];
    NSLayoutConstraint *rigthConstraint = [NSLayoutConstraint
                                           constraintWithItem:v
                                           attribute:NSLayoutAttributeRight
                                           relatedBy:NSLayoutRelationEqual
                                           toItem:self.view
                                           attribute:NSLayoutAttributeRight
                                           multiplier:1
                                           constant:-20];
    NSLayoutConstraint *heightConstraint = [NSLayoutConstraint
                                            constraintWithItem:v
                                            attribute:NSLayoutAttributeHeight
                                            relatedBy:NSLayoutRelationEqual
                                            toItem:nil
                                            attribute:NSLayoutAttributeHeight
                                            multiplier:1
                                            constant:60];
    [v addConstraint:heightConstraint];
    [self.view addConstraints:@[topConstraint, leftConstraint,rigthConstraint]];
    
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillDisappear:(BOOL)animated{
     [self.navigationController setToolbarHidden:NO animated:NO];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
